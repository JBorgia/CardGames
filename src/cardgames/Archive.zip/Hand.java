package cardgames;

import java.util.ArrayList;
import java.util.List;
/*Hand holds the cards for each player/dealer*/
public class Hand {
	List<Card> hand = new ArrayList<>();
	
}
