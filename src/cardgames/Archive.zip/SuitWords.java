package cardgames;
/*list of suits*/
public enum SuitWords {
	Hearts, Spades, Diamonds, Clubs
}
